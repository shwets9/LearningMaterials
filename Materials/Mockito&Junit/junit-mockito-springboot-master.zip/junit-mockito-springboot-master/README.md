# junit-mockito-springboot
Unit testing with jUnit + Mockito on a Spring Boot test project to show Mockito's capabilities.

A basic Spring Boot Tomcat project for a unit testing talk at work. 
The main purpose is learning about good practices developing jUnit tests with Mockito.
Contains advanced techniques for testing with Mockito, like Captors and Answers.
