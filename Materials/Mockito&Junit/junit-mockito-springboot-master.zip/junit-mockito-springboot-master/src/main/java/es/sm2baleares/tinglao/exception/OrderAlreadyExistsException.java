package es.sm2baleares.tinglao.exception;

/**
 * Created by pablo.beltran on 22/09/2016.
 */
public class OrderAlreadyExistsException extends Exception {
}
