package es.sm2baleares.tinglao.exception;

/**
 * Created by pablo.beltran on 21/09/2016.
 */
public class OrderException extends Throwable {

	public OrderException(String message) {
		super(message);
	}
}
