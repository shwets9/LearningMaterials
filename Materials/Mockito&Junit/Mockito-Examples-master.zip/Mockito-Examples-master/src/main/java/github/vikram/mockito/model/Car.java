package github.vikram.mockito.model;

public class Car extends Vehicle {

	public Car(String make, String model, int miles, String vehicleId, double price) {
		super(vehicleId, price, make, model, miles);
		
	}

}
