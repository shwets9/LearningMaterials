package github.vikram.mockito.model;

public class Van extends Vehicle {

	public Van(String make, String model, int miles, String vehicleId, double price) {
		super(vehicleId, price, make, model, miles);
		// TODO Auto-generated constructor stub
	}

}
