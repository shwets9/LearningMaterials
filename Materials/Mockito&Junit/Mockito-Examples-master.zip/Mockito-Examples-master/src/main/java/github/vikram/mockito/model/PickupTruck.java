package github.vikram.mockito.model;

public class PickupTruck extends Vehicle {

	public PickupTruck(String make, String model, int miles, String vehicleId, double price) {
		super(vehicleId, price, make, model, miles);
		// TODO Auto-generated constructor stub
	}

}
