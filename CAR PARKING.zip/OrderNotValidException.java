package Thursday;

@SuppressWarnings("serial")
public class OrderNotValidException extends Exception{
	public OrderNotValidException(String message)
	{
		super(message);
	}

}
