package Thursday;

public class customer_last {
	private int custNo;
	private String custName;
	public customer_last(int custNo, String custName) {
		super();
		this.custNo = custNo;
		this.custName = custName;
	}
	public int getCustNo() {
		return custNo;
	}
	public void setCustNo(int custNo) {
		this.custNo = custNo;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String toString()
	{
		return "Customer no: "+custNo+" Customer Name: "+custName;
	}
	


}
