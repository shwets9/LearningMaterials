package Thursday;

import java.util.Hashtable;


public class MyShopping {
	private Hashtable < customer_last, Order > h=new Hashtable<>();
	public void storeRecord(customer_last cl, Order od)
	{
		h.put(cl, od);
	}
	public void getRecord(customer_last cl)
	{
		System.out.print(cl.toString()+" ");
		System.out.println(h.get(cl).toString());
	}
	

}
